# Discord-Nitro-Proof-Bot
Sends a picture of "nitro proof" after use of the commands, Can be used in fake nitro servers ect. Commands are (prefix)boost (username) (text) and classic (username) (text)

Scrapes profile pictures from servers that the bot is in.

Credits: !! Snowwy#1337 or https://snowwy.wtf

Put ur bot token in config.json

Run install.bat then once all the modules are installed run run.bat

YOU NEED THE NODE.JS https://nodejs.org/en/download/

![Nitro Example](images/1.PNG)
![Classic Example](images/2.PNG)
